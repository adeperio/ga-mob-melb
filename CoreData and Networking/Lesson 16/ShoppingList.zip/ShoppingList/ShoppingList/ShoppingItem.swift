//
//  ShoppingItem.swift
//  ShoppingList
//
//  Created by Antonio de Perio on 14/01/2016.
//  Copyright © 2016 Workshop. All rights reserved.
//

import Foundation
import CoreData

@objc(ShoppingItem)
class ShoppingItem: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
