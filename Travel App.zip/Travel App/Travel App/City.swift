//
//  City.swift
//  Travel App
//
//  Created by Brett J. Rapp on 1/12/2015.
//  Copyright © 2015 Brett J. Rapp. All rights reserved.
//

import Foundation

class City: Place {
    

    var population: String = ""

    
    
}