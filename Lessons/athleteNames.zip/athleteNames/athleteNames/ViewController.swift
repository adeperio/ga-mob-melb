//
//  ViewController.swift
//  athleteNames
//
//  Created by Sam Wijesinha on 12/01/2016.
//  Copyright © 2016 SamWij. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tablevView: UITableView!
   
    var getAthleteNames : [AnyObject]?


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
       self.getAthleteNames =  NSUserDefaults.standardUserDefaults().arrayForKey("PrintAthlete")
         
        for i in getAthleteNames! {
            print(i)
        }
        
        
    }

    
   func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return getAthleteNames!.count
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cellid", forIndexPath: indexPath)
        
        //Configure the cell...
        cell.textLabel!.text = self.getAthleteNames![indexPath.row] as? String
        
        
        return cell
    }
    
    

}

